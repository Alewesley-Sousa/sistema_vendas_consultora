<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Administrativo - Sistema de Vendas</title>
    <link rel="stylesheet" href="estilo.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root {
            --primary: #667eea;
            --primary-dark: #764ba2;
            --success: #27ae60;
            --danger: #e74c3c;
            --card: #ffffff;
            --bg: #f6f8ff;
            --text: #333;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(180deg, #eef2ff 0%, #f7f9ff 100%);
            color: var(--text);
            line-height: 1.45;
        }

        .admin-container {
            max-width: 1200px;
            margin: 16px auto;
            padding: 16px;
            min-height: calc(100vh - 32px);
        }

        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 18px;
            background: rgba(255, 255, 255, 0.95);
            padding: 16px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            border: 1px solid #e8ebfa;
        }

        .admin-title h1 {
            color: #333;
            margin: 0;
            font-size: 28px;
        }

        .admin-title p {
            color: #666;
            margin: 5px 0 0 0;
        }

        .admin-actions {
            display: flex;
            gap: 15px;
        }

        .btn-admin {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }

        .btn-secondary {
            background: #f8f9fa;
            color: #333;
            border: 2px solid #e9ecef;
        }

        .btn-secondary:hover {
            background: #e9ecef;
        }

        .btn-danger {
            background: #e74c3c;
            color: white;
        }

        .btn-danger:hover {
            background: #c0392b;
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .dashboard-card {
            background: var(--card);
            border-radius: 14px;
            padding: 18px;
            box-shadow: 0 6px 18px rgba(0, 0, 0, 0.06);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            border: 1px solid #eef1ff;
        }

        .dashboard-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
        }

        .card-header {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        .card-icon {
            font-size: 24px;
            margin-right: 15px;
        }

        .card-title {
            font-size: 18px;
            font-weight: bold;
            color: #333;
            margin: 0;
        }

        .card-value {
            font-size: 32px;
            font-weight: bold;
            color: #667eea;
            margin: 10px 0;
        }

        .card-subtitle {
            color: #666;
            font-size: 14px;
        }

        .users-section, .clients-section {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 14px;
            padding: 18px;
            margin-bottom: 24px;
            box-shadow: 0 8px 18px rgba(0, 0, 0, 0.08);
            border: 1px solid #edf0ff;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .section-title {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            margin: 0;
        }

        .section-actions {
            display: flex;
            gap: 10px;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        .users-table, .clients-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 16px;
            min-width: 600px;
        }

        .users-table th, .users-table td,
        .clients-table th, .clients-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e9ecff;
            font-size: 14px;
        }

        .users-table th, .clients-table th {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-weight: bold;
        }

        .users-table tr:hover, .clients-table tr:hover {
            background: rgba(102, 126, 234, 0.05);
        }

        .role-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .role-admin {
            background: #e74c3c;
            color: white;
        }

        .role-funcionario {
            background: #f39c12;
            color: white;
        }

        .role-cliente {
            background: #27ae60;
            color: white;
        }

        .status-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: bold;
        }

        .status-ativo {
            background: #27ae60;
            color: white;
        }

        .status-inativo {
            background: #e74c3c;
            color: white;
        }

        .status-pendente {
            background: #f39c12;
            color: white;
        }

        .action-buttons {
            display: flex;
            gap: 5px;
        }

        .btn-small {
            padding: 6px 12px;
            border: none;
            border-radius: 5px;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-edit {
            background: #f39c12;
            color: white;
        }

        .btn-edit:hover {
            background: #e67e22;
        }

        .btn-delete {
            background: #e74c3c;
            color: white;
        }

        .btn-delete:hover {
            background: #c0392b;
        }

        .btn-promote {
            background: #27ae60;
            color: white;
        }

        .btn-promote:hover {
            background: #229954;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .modal-content {
            background: white;
            border-radius: 15px;
            padding: 30px;
            width: 90%;
            max-width: 600px;
            animation: modalFadeIn 0.3s ease;
        }

        @keyframes modalFadeIn {
            from { opacity: 0; transform: scale(0.9); }
            to { opacity: 1; transform: scale(1); }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .modal-header h2 {
            margin: 0;
            color: #333;
        }

        .close-btn {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #999;
        }

        .close-btn:hover {
            color: #333;
        }

        .form-row {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
        }

        .form-row .form-group {
            flex: 1;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        .form-group input, .form-group select {
            width: 100%;
            padding: 10px;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            font-size: 14px;
            text-align: center;
        }

        .form-group input:focus, .form-group select:focus {
            border-color: #667eea;
            outline: none;
        }

        .modal-footer {
            text-align: right;
            margin-top: 20px;
        }

        .no-data {
            text-align: center;
            color: #999;
            font-style: italic;
            padding: 40px;
        }

        @media (max-width: 768px) {
            .admin-header {
                flex-direction: column;
                gap: 20px;
                text-align: center;
            }

            .admin-actions {
                flex-wrap: wrap;
                justify-content: center;
            }

            .dashboard-grid {
                grid-template-columns: 1fr;
            }

            .section-header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }

            .form-row {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="admin-header">
            <div class="admin-title">
                <h1>Painel Administrativo</h1>
                <p>Gerencie usuários e clientes do sistema</p>
            </div>
            <div class="admin-actions">
                <button class="btn-admin btn-primary" onclick="openAddUserModal()">
                    <i class="fas fa-user-plus"></i> Adicionar Usuário
                </button>
                <button class="btn-admin btn-secondary" onclick="window.location.href='clientes.html'">
                    <i class="fas fa-users"></i> Ver Clientes
                </button>
                <button class="btn-admin btn-danger" onclick="logout()">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </button>
            </div>
        </div>

        <div class="dashboard-grid">
            <div class="dashboard-card">
                <div class="card-header">
                    <div class="card-icon"><i class="fas fa-users"></i></div>
                    <h3 class="card-title">Total de Usuários</h3>
                </div>
                <div class="card-value" id="totalUsers">0</div>
                <div class="card-subtitle">Usuários registrados no sistema</div>
            </div>

            <div class="dashboard-card">
                <div class="card-header">
                    <div class="card-icon"><i class="fas fa-user-tie"></i></div>
                    <h3 class="card-title">Funcionários</h3>
                </div>
                <div class="card-value" id="totalFuncionarios">0</div>
                <div class="card-subtitle">Usuários com papel de funcionário</div>
            </div>

            <div class="dashboard-card">
                <div class="card-header">
                    <div class="card-icon"><i class="fas fa-user"></i></div>
                    <h3 class="card-title">Clientes</h3>
                </div>
                <div class="card-value" id="totalClientes">0</div>
                <div class="card-subtitle">Usuários com papel de cliente</div>
            </div>

            <div class="dashboard-card">
                <div class="card-header">
                    <div class="card-icon"><i class="fas fa-chart-bar"></i></div>
                    <h3 class="card-title">Clientes Sistema</h3>
                </div>
                <div class="card-value" id="totalClientesSistema">0</div>
                <div class="card-subtitle">Clientes cadastrados no sistema</div>
            </div>
        </div>

        <div class="users-section">
            <div class="section-header">
                <h2 class="section-title">Gerenciamento de Usuários</h2>
                <div class="section-actions">
                    <input type="text" id="userSearch" placeholder="Buscar usuários..." style="padding: 8px; border: 1px solid #ddd; border-radius: 5px;">
                </div>
            </div>
            <div class="table-wrapper">
                <table class="users-table">
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>E-mail</th>
                            <th>Papel</th>
                            <th>Data Cadastro</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody id="usersTableBody">
                        <tr>
                            <td colspan="5" class="no-data">Carregando usuários...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal para adicionar/editar usuário -->
    <div id="userModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle">Adicionar Usuário</h2>
                <button class="close-btn" onclick="closeModal()">&times;</button>
            </div>
            <form id="userForm">
                <input type="hidden" id="userId">
                <div class="form-row">
                    <div class="form-group">
                        <label for="userFirstName">Nome</label>
                        <input type="text" id="userFirstName" required>
                    </div>
                    <div class="form-group">
                        <label for="userLastName">Sobrenome</label>
                        <input type="text" id="userLastName" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="userEmail">E-mail</label>
                    <input type="email" id="userEmail" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="userPassword">Senha</label>
                        <input type="password" id="userPassword" required>
                    </div>
                    <div class="form-group">
                        <label for="userRole">Papel</label>
                        <select id="userRole" required>
                            <option value="cliente">Cliente</option>
                            <option value="funcionario">Funcionário</option>
                            <option value="admin">Administrador</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn-admin btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        let users = [];
        let currentUser = null;
        let editUserId = null;

        // Verificar se usuário está logado e é admin
        document.addEventListener('DOMContentLoaded', function() {
            currentUser = JSON.parse(localStorage.getItem('currentUser'));

            if (!currentUser || currentUser.role !== 'admin') {
                alert('Acesso negado! Apenas administradores podem acessar esta página.');
                window.location.href = 'login.html';
                return;
            }

            loadUsers();
            loadDashboardStats();
            setupSearch();
        });

        function loadUsers() {
            users = JSON.parse(localStorage.getItem('users')) || [];
            renderUsersTable();
        }

        function loadDashboardStats() {
            const clientesSistema = JSON.parse(localStorage.getItem('clientes')) || [];

            document.getElementById('totalUsers').textContent = users.length;
            document.getElementById('totalFuncionarios').textContent = users.filter(u => u.role === 'funcionario').length;
            document.getElementById('totalClientes').textContent = users.filter(u => u.role === 'cliente').length;
            document.getElementById('totalClientesSistema').textContent = clientesSistema.length;
        }

        function renderUsersTable(filteredUsers = null) {
            const tbody = document.getElementById('usersTableBody');
            const usersToShow = filteredUsers || users;

            if (usersToShow.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" class="no-data">Nenhum usuário encontrado.</td></tr>';
                return;
            }

            tbody.innerHTML = usersToShow.map(user => `
                <tr>
                    <td>${user.firstName} ${user.lastName}</td>
                    <td>${user.email}</td>
                    <td><span class="role-badge role-${user.role}">${user.role}</span></td>
                    <td>${new Date(user.createdAt).toLocaleDateString('pt-BR')}</td>
                    <td class="action-buttons">
                        <button class="btn-small btn-edit" onclick="editUser('${user.id}')">Editar</button>
                        ${user.id !== '1' ? `<button class="btn-small btn-delete" onclick="deleteUser('${user.id}')">Excluir</button>` : ''}
                        ${user.role === 'cliente' ? `<button class="btn-small btn-promote" onclick="promoteUser('${user.id}')">Promover</button>` : ''}
                    </td>
                </tr>
            `).join('');
        }

        function setupSearch() {
            document.getElementById('userSearch').addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                const filteredUsers = users.filter(user =>
                    user.firstName.toLowerCase().includes(searchTerm) ||
                    user.lastName.toLowerCase().includes(searchTerm) ||
                    user.email.toLowerCase().includes(searchTerm) ||
                    user.role.toLowerCase().includes(searchTerm)
                );
                renderUsersTable(filteredUsers);
            });
        }

        function openAddUserModal() {
            editUserId = null;
            document.getElementById('modalTitle').textContent = 'Adicionar Usuário';
            document.getElementById('userForm').reset();
            document.getElementById('userId').value = '';
            document.getElementById('userModal').style.display = 'flex';
        }

        function editUser(userId) {
            const user = users.find(u => u.id === userId);
            if (!user) return;

            editUserId = userId;
            document.getElementById('modalTitle').textContent = 'Editar Usuário';
            document.getElementById('userId').value = user.id;
            document.getElementById('userFirstName').value = user.firstName;
            document.getElementById('userLastName').value = user.lastName;
            document.getElementById('userEmail').value = user.email;
            document.getElementById('userPassword').value = user.password;
            document.getElementById('userRole').value = user.role;

            document.getElementById('userModal').style.display = 'flex';
        }

        function deleteUser(userId) {
            if (userId === '1') {
                alert('Não é possível excluir o usuário administrador padrão!');
                return;
            }

            if (confirm('Tem certeza que deseja excluir este usuário?')) {
                users = users.filter(u => u.id !== userId);
                localStorage.setItem('users', JSON.stringify(users));
                loadUsers();
                loadDashboardStats();
                showMessage('Usuário excluído com sucesso!', 'success');
            }
        }

        function promoteUser(userId) {
            const user = users.find(u => u.id === userId);
            if (!user) return;

            const newRole = user.role === 'cliente' ? 'funcionario' : 'admin';
            user.role = newRole;

            localStorage.setItem('users', JSON.stringify(users));
            loadUsers();
            loadDashboardStats();
            showMessage(`Usuário promovido para ${newRole}!`, 'success');
        }

        function closeModal() {
            document.getElementById('userModal').style.display = 'none';
            editUserId = null;
        }

        document.getElementById('userForm').addEventListener('submit', function(e) {
            e.preventDefault();

            const userData = {
                id: editUserId || Date.now().toString(),
                firstName: document.getElementById('userFirstName').value.trim(),
                lastName: document.getElementById('userLastName').value.trim(),
                email: document.getElementById('userEmail').value.trim(),
                password: document.getElementById('userPassword').value,
                role: document.getElementById('userRole').value,
                createdAt: editUserId ? users.find(u => u.id === editUserId).createdAt : new Date().toISOString()
            };

            // Verificar se e-mail já existe (exceto para o usuário sendo editado)
            const existingUser = users.find(u => u.email === userData.email && u.id !== editUserId);
            if (existingUser) {
                alert('Este e-mail já está cadastrado!');
                return;
            }

            if (editUserId) {
                // Editar usuário existente
                const index = users.findIndex(u => u.id === editUserId);
                users[index] = userData;
                showMessage('Usuário atualizado com sucesso!', 'success');
            } else {
                // Adicionar novo usuário
                users.push(userData);
                showMessage('Usuário adicionado com sucesso!', 'success');
            }

            localStorage.setItem('users', JSON.stringify(users));
            closeModal();
            loadUsers();
            loadDashboardStats();
        });

        function logout() {
            localStorage.removeItem('currentUser');
            window.location.href = 'login.html';
        }

        function showMessage(message, type) {
            const messageEl = document.createElement('div');
            messageEl.textContent = message;
            messageEl.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: ${type === 'success' ? '#27ae60' : '#e74c3c'};
                color: white;
                padding: 15px 20px;
                border-radius: 8px;
                box-shadow: 0 5px 15px rgba(0,0,0,0.2);
                z-index: 1001;
                animation: slideIn 0.3s ease;
            `;

            document.body.appendChild(messageEl);

            setTimeout(() => {
                messageEl.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => document.body.removeChild(messageEl), 300);
            }, 3000);
        }

        // Animações CSS
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes slideOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
        `;
        document.head.appendChild(style);

        // Fechar modal ao clicar fora
        window.addEventListener('click', function(e) {
            const modal = document.getElementById('userModal');
            if (e.target === modal) {
                closeModal();
            }
        });
    </script>
</body>